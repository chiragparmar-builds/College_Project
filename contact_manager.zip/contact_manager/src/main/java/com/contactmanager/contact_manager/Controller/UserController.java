package com.contactmanager.contact_manager.Controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.contactmanager.contact_manager.dao.UserRepository;
import com.contactmanager.contact_manager.entities.User;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @RequestMapping("/index")
    public String requestMethodName(Model m,Principal principal) {
        String username = principal.getName();
        User u = userRepository.getUserByUserName(username);
        m.addAttribute("user", u);
        m.addAttribute("mode", "");
        // System.out.println(u);
        return "/user/DashBord";
    }

    // @GetMapping("/")
    // public String DashBordPage(Model m) {
    //     m.addAttribute("Title", "DashBord");
    //     return "/user/DashBord";
    // }
}
