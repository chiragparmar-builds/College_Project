# ONLINE_RESUME_BUILDER_PROJECT
i created this project in spring boot with hibernet config for my college final year 
